package ro.ase.semdam_1084;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class BarChartActivity extends AppCompatActivity {

    ArrayList<BiletAvion> list;
    LinearLayout layout;
    Map<String, Integer> source;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_bar_chart);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Intent intent = getIntent();

        list = (ArrayList<BiletAvion>) intent.getSerializableExtra("list");

        source = getSource(list);

        layout = findViewById(R.id.layoutBar);
        layout.addView(new BarChartView(getApplicationContext(), source));
    }

    private Map<String, Integer> getSource(List<BiletAvion> biletAvionList)
    {
        if(biletAvionList==null || biletAvionList.isEmpty())
            return new HashMap<>();
        else
        {
            Map<String, Integer> results = new HashMap<>();
            for(BiletAvion biletAvion: biletAvionList)
                if(results.containsKey(biletAvion.getCategorieBilet()))
                    results.put(biletAvion.getCategorieBilet(),
                            results.get(biletAvion.getCategorieBilet())+1);
            else
                results.put(biletAvion.getCategorieBilet(), 1);
            return results;
        }
    }
}