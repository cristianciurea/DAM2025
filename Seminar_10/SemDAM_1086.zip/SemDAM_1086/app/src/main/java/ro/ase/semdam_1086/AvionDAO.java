package ro.ase.semdam_1086;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface AvionDAO {

    @Insert
    void insert(Avion avion);

    @Insert
    void insert(List<Avion> avionList);

    @Query("select * from avioane")
    List<Avion> getAll();

    @Query("delete from avioane")
    void deleteAll();

    @Delete
    void delete(Avion avion);

    @Update
    void update(Avion avion);
}
