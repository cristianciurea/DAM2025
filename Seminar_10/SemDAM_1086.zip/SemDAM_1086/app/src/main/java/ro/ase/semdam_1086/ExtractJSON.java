package ro.ase.semdam_1086;

import android.os.AsyncTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class ExtractJSON extends AsyncTask<URL, Void, String> {

    List<Avion> avionListJSON = new ArrayList<>();

    @Override
    protected String doInBackground(URL... urls) {

        HttpURLConnection connection = null;

        try {
            connection = (HttpURLConnection) urls[0].openConnection();
            connection.setRequestMethod("GET");
            InputStream ist = connection.getInputStream();

            InputStreamReader isr = new InputStreamReader(ist);
            BufferedReader br = new BufferedReader(isr);
            String linie = null;
            String rezultat="";
            while ((linie = br.readLine())!=null)
                rezultat+=linie;

            parsareJSON(rezultat);

            return rezultat;

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void parsareJSON(String jsonStr)
    {
        try {
            JSONObject jsonObject = new JSONObject(jsonStr);
            JSONArray avioane = jsonObject.getJSONArray("Avioane");
            for(int i=0;i<avioane.length();i++)
            {
                JSONObject obj = avioane.getJSONObject(i);

                String producator = obj.getString("Producator");
                Date dataFabricatiei = new Date(obj.getString("DataFabricatiei"));
                int nrLocuri = Integer.parseInt(obj.getString("NrLocuri"));
                String model = obj.getString("Model");
                boolean esteDefect = Boolean.parseBoolean(obj.getString("EsteDefect"));

                Avion avion = new Avion(producator, dataFabricatiei, nrLocuri, model, esteDefect);
                avionListJSON.add(avion);
            }
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }
}
