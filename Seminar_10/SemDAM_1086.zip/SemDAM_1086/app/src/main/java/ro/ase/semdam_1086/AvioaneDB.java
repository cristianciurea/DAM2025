package ro.ase.semdam_1086;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

@Database(entities = {Avion.class}, version = 1, exportSchema = false)
@TypeConverters({DateConverter.class})
public abstract class AvioaneDB extends RoomDatabase {

    public static final String DB_NAME = "avioane.db";

    private static AvioaneDB instanta;

    public static AvioaneDB getInstanta(Context context)
    {
        if(instanta==null)
            instanta = Room.databaseBuilder(context,
                    AvioaneDB.class, DB_NAME)
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build();

        return instanta;
    }

    public abstract AvionDAO getAvionDao();
}
