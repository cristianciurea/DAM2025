package ro.ase.semdam_1086;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class BNRActivity extends AppCompatActivity {

    TextView tvData;
    EditText etEUR, etUSD, etGBP, etXAU;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_bnr);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Log.e("lifecycle", "Apel onCreate");

         tvData = findViewById(R.id.tvData);
         etEUR = findViewById(R.id.editTextEUR);
         etUSD = findViewById(R.id.editTextUSD);
         etGBP = findViewById(R.id.editTextGBP);
         etXAU = findViewById(R.id.editTextXAU);

        Button btnShow = findViewById(R.id.btnShow);
        btnShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*Toast.makeText(getApplicationContext(), "Click pe buton!", Toast.LENGTH_LONG).show();

                tvData.setText("2025/09/30");
                etEUR.setText("5.2456");
                etUSD.setText("4.3456");
                etGBP.setText("5.7890");
                etXAU.setText("524.6789");*/
                Network network = new Network(){
                    @Override
                    protected void onPostExecute(InputStream inputStream) {

                        /*Toast.makeText(getApplicationContext(), Network.rezultat,
                                Toast.LENGTH_LONG).show();*/
                        tvData.setText(cv.getDataCurs());
                        etEUR.setText(cv.getCursEUR());
                        etUSD.setText(cv.getCursUSD());
                        etGBP.setText(cv.getCursGBP());
                        etXAU.setText(cv.getCursXAU());
                    }
                };
                try {
                    network.execute(new URL("https://bnr.ro/nbrfxrates.xml"));
                } catch (MalformedURLException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        Button btnSalvare = findViewById(R.id.btnSave);
        btnSalvare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CursValutar cursValutar = new CursValutar(tvData.getText().toString(),
                        etEUR.getText().toString(),
                        etUSD.getText().toString(),
                        etGBP.getText().toString(),
                        etXAU.getText().toString());

                try {
                    scrieInFisier(cursValutar, "cursuri.dat");
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.e("lifecycle", "Apel onStart");

        Intent intent = getIntent();
        CursValutar cursValutar = (CursValutar) intent.getSerializableExtra("cursValutar");
        if(cursValutar!=null)
        {
            tvData.setText(cursValutar.getDataCurs());
            etEUR.setText(cursValutar.getCursEUR());
            etUSD.setText(cursValutar.getCursUSD());
            etGBP.setText(cursValutar.getCursGBP());
            etXAU.setText(cursValutar.getCursXAU());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("lifecycle", "Apel onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.e("lifecycle", "Apel onPause");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.e("lifecycle", "Apel onRestart");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.e("lifecycle", "Apel onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e("lifecycle", "Apel onDestroy");
    }

    public void scrieInFisier(CursValutar cursValutar, String denumireFisier) throws IOException {

        FileOutputStream fileOutputStream = openFileOutput(denumireFisier, Activity.MODE_PRIVATE);
        DataOutputStream dataOutputStream = new DataOutputStream(fileOutputStream);
        dataOutputStream.writeUTF(cursValutar.getDataCurs());
        dataOutputStream.writeUTF(cursValutar.getCursEUR());
        dataOutputStream.writeUTF(cursValutar.getCursUSD());
        dataOutputStream.writeUTF(cursValutar.getCursGBP());
        dataOutputStream.writeUTF(cursValutar.getCursXAU());
        dataOutputStream.flush();
        fileOutputStream.close();
    }

    public CursValutar citireDinFisier(String denumireFisier) throws IOException
    {
        FileInputStream fileInputStream = openFileInput(denumireFisier);
        DataInputStream dataInputStream = new DataInputStream(fileInputStream);
        String dataCurs = dataInputStream.readUTF();
        String cursEUR = dataInputStream.readUTF();
        String cursUSD = dataInputStream.readUTF();
        String cursGBP = dataInputStream.readUTF();
        String cursXAU = dataInputStream.readUTF();
        CursValutar cursValutar = new CursValutar(dataCurs, cursEUR, cursUSD, cursGBP, cursXAU);
        fileInputStream.close();
        return cursValutar;
    }
}