package ro.ase.semdam_1086;

import android.content.Intent;
import android.os.Bundle;

import com.androidplot.xy.LineAndPointFormatter;
import com.androidplot.xy.SimpleXYSeries;
import com.androidplot.xy.XYPlot;
import com.androidplot.xy.XYSeries;

import java.util.ArrayList;
import java.util.List;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class GraficActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_grafic);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Intent intent = getIntent();

        ArrayList<Avion> avionArrayList = (ArrayList<Avion>) intent.getSerializableExtra("list");

        List<Double> listLocuriDA = new ArrayList<>();
        List<Double> listLocuriNU = new ArrayList<>();

        for(Avion avion: avionArrayList)
            if(avion.isEsteDefect())
                listLocuriDA.add(Double.valueOf(avion.getNrLocuri()));
        else
            listLocuriNU.add(Double.valueOf(avion.getNrLocuri()));

        XYPlot plot = findViewById(R.id.myXYPlot);
        plot.setTitle("Grafic numar locuri avioane");

        XYSeries series1 = new SimpleXYSeries(listLocuriDA, SimpleXYSeries.ArrayFormat.Y_VALS_ONLY, "DA");
        plot.addSeries(series1, new LineAndPointFormatter(getApplicationContext(), R.layout.f1));

        XYSeries series2 = new SimpleXYSeries(listLocuriNU, SimpleXYSeries.ArrayFormat.Y_VALS_ONLY, "NU");
        plot.addSeries(series2, new LineAndPointFormatter(getApplicationContext(), R.layout.f2));

    }
}