package ro.ase.semdam_1086;

import java.io.Serializable;
import java.util.Date;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "avioane")
public class Avion implements Serializable {

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String producator;
    private Date dataFabricatiei;
    private int nrLocuri;
    private String model;//A320, A330, 787, 737
    private boolean esteDefect;//DA, NU

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    @Ignore
    private String uid;

    @Ignore
    public Avion(){}

    public Avion(String producator, Date dataFabricatiei, int nrLocuri, String model, boolean esteDefect) {
        this.producator = producator;
        this.dataFabricatiei = dataFabricatiei;
        this.nrLocuri = nrLocuri;
        this.model = model;
        this.esteDefect = esteDefect;
    }

    public String getProducator() {
        return producator;
    }

    public void setProducator(String producator) {
        this.producator = producator;
    }

    public Date getDataFabricatiei() {
        return dataFabricatiei;
    }

    public void setDataFabricatiei(Date dataFabricatiei) {
        this.dataFabricatiei = dataFabricatiei;
    }

    public int getNrLocuri() {
        return nrLocuri;
    }

    public void setNrLocuri(int nrLocuri) {
        this.nrLocuri = nrLocuri;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public boolean isEsteDefect() {
        return esteDefect;
    }

    public void setEsteDefect(boolean esteDefect) {
        this.esteDefect = esteDefect;
    }

    @Override
    public String toString() {
        return "Avion{" +
                "producator='" + producator + '\'' +
                ", dataFabricatiei=" + dataFabricatiei +
                ", nrLocuri=" + nrLocuri +
                ", model='" + model + '\'' +
                ", esteDefect=" + esteDefect +
                '}';
    }
}
