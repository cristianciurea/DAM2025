package ro.ase.semdam_1086;

import android.content.Intent;
import android.os.Bundle;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SplashScreen extends AppCompatActivity {

    CursValutar cvSplash = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_splash_screen);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Thread splashThread = new Thread()
        {
            @Override
            public void run() {

                Network network = new Network()
                {
                    @Override
                    protected void onPostExecute(InputStream inputStream) {
                        cvSplash = cv;
                    }
                };
                try {
                    network.execute(new URL("https://bnr.ro/nbrfxrates.xml"));

                    sleep(5000);

                } catch (MalformedURLException e) {
                    throw new RuntimeException(e);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                finally {
                    Intent intent = new Intent(getApplicationContext(),BNRActivity.class);
                    intent.putExtra("cursValutar", cvSplash);
                    startActivity(intent);
                    finish();
                }
            }
        };
        splashThread.start();
    }
}