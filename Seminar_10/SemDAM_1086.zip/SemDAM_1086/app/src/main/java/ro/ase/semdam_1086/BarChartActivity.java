package ro.ase.semdam_1086;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class BarChartActivity extends AppCompatActivity {

    ArrayList<Avion> list;
    LinearLayout layout;
    Map<String, Integer> source;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_bar_chart);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Intent intent = getIntent();

        list = (ArrayList<Avion>) intent.getSerializableExtra("list");

        source = getSource(list);

        layout = findViewById(R.id.layouBar);
        layout.addView(new BarChartView(getApplicationContext(), source));

    }

    private Map<String, Integer> getSource(List<Avion> avionList)
    {
        if(avionList==null || avionList.isEmpty())
            return new HashMap<>();
        else
        {
            Map<String, Integer> results = new HashMap<>();
            for(Avion avion: avionList)
                if(results.containsKey(avion.getProducator()))
                    results.put(avion.getProducator(),
                            results.get(avion.getProducator())+1);
            else
                results.put(avion.getProducator(), 1);
            return  results;

        }
    }
}