package ro.ase.semdam_1084;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class BNRActivity extends AppCompatActivity implements View.OnClickListener {

    TextView tv1;
    EditText etEUR, etUSD, etGBP, etXAU;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_bnr);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

       /* tv1 = findViewById(R.id.textView2);
        tv1.setText("Text modificat din cod");*/

        Button btnShow = findViewById(R.id.btnShow);
        btnShow.setOnClickListener(this);
        /*btnShow.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Toast.makeText(getApplicationContext(), "Click pe buton!", Toast.LENGTH_LONG).show();
           }
       });*/
        tv1 = findViewById(R.id.tvData);
        etEUR = findViewById(R.id.editTextEUR);
        etUSD = findViewById(R.id.editTextUSD);
        etGBP = findViewById(R.id.editTextGBP);
        etXAU = findViewById(R.id.editTextXAU);
    }

    @Override
    public void onClick(View view) {
        /*etEUR.setText("5.23");
        etUSD.setText("4.34");
        etGBP.setText("6.58");
        etXAU.setText("524.56");*/
        Network network = new Network(){
            @Override
            protected void onPostExecute(InputStream inputStream) {
                /*Toast.makeText(getApplicationContext(),
                        Network.rezultat, Toast.LENGTH_LONG).show();*/
                tv1.setText(cv.getDataCurs());
                etEUR.setText(cv.getCursEUR());
                etUSD.setText(cv.getCursUSD());
                etGBP.setText(cv.getCursGBP());
                etXAU.setText(cv.getCursXAU());
            }
        };
        try {
            network.execute(new URL("https://bnr.ro/nbrfxrates.xml"));
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
    }
}