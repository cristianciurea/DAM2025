package ro.ase.semdam_1084;

import java.io.Serializable;
import java.util.Date;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "bilete")
public class BiletAvion implements Serializable {

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String destinatie;
    private Date dataZbor;
    private float pret;
    private String companie; //Tarom, Ryanair, WizzAir, HiSky
    private String categorieBilet; //ECONOMY, BUSINESS

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    @Ignore
    private String uid;

    @Ignore
    public BiletAvion(){}

    public BiletAvion(String destinatie, Date dataZbor, float pret, String companie, String categorieBilet) {
        this.destinatie = destinatie;
        this.dataZbor = dataZbor;
        this.pret = pret;
        this.companie = companie;
        this.categorieBilet = categorieBilet;
    }

    public String getDestinatie() {
        return destinatie;
    }

    public void setDestinatie(String destinatie) {
        this.destinatie = destinatie;
    }

    public Date getDataZbor() {
        return dataZbor;
    }

    public void setDataZbor(Date dataZbor) {
        this.dataZbor = dataZbor;
    }

    public float getPret() {
        return pret;
    }

    public void setPret(float pret) {
        this.pret = pret;
    }

    public String getCompanie() {
        return companie;
    }

    public void setCompanie(String companie) {
        this.companie = companie;
    }

    public String getCategorieBilet() {
        return categorieBilet;
    }

    public void setCategorieBilet(String categorieBilet) {
        this.categorieBilet = categorieBilet;
    }

    @Override
    public String toString() {
        return "BiletAvion{" +
                "destinatie='" + destinatie + '\'' +
                ", dataZbor=" + dataZbor +
                ", pret=" + pret +
                ", companie='" + companie + '\'' +
                ", categorieBilet='" + categorieBilet + '\'' +
                '}';
    }
}
