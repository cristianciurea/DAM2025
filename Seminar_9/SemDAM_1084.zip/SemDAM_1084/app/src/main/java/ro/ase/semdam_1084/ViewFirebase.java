package ro.ase.semdam_1084;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ViewFirebase extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //EdgeToEdge.enable(this);

        ListView listView = new ListView(this);

        List<BiletAvion> biletAvionList = new ArrayList<>();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("semdam-1084-2dbcb-default-rtdb");

        ValueEventListener listener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                if(snapshot.exists())
                {
                    biletAvionList.clear();
                    for(DataSnapshot dn: snapshot.getChildren())
                    {
                        BiletAvion biletAvion = dn.getValue(BiletAvion.class);
                        biletAvionList.add(biletAvion);
                    }
                }
                ArrayAdapter<BiletAvion> adapter = new ArrayAdapter<>(getApplicationContext(),
                        android.R.layout.simple_list_item_1,
                        biletAvionList);
                listView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        };
        myRef.child("semdam-1084-2dbcb-default-rtdb").addValueEventListener(listener);

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {

                BiletAvion biletAvion = biletAvionList.get(position);
                biletAvionList.remove(biletAvion);

                myRef.child("semdam-1084-2dbcb-default-rtdb").child(biletAvion.getUid()).removeValue();

                ArrayAdapter<BiletAvion> adapter = new ArrayAdapter<>(getApplicationContext(),
                        android.R.layout.simple_list_item_1,
                        biletAvionList);
                listView.setAdapter(adapter);

                return true;
            }
        });

        HorizontalScrollView sv = new HorizontalScrollView(this);
        //sv.setId(Integer.parseInt("sv"));

        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);

        params.setMargins(0, 300, 0, 0);

        TextView textView = new TextView(this);
        textView.setText("Lista bilete din Firebase\n");

        ll.addView(textView);
        ll.addView(listView);
        sv.addView(ll);
        sv.setLayoutParams(params);

        setContentView(sv);

       /* ViewCompat.setOnApplyWindowInsetsListener(findViewById(sv.getId()), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });*/
    }
}
